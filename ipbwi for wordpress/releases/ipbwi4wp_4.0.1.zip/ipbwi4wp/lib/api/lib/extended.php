<?php
	declare(strict_types=1);
	
	/**
	 * @author			Matthias Reuter
	 * @package			extended
	 * @copyright		2007-2016 Matthias Reuter
	 * @link			http://ipbwi.com/
	 * @since			4.0.1
	 * @license			This is no free software. See license.txt or https://ipbwi.com
	 */
	class ipbwi_extended extends ipbwi{
		public $ipbwi			= null;
		/**
		 * @desc			Loads other classes of package
		 * @author			Matthias Reuter
		 * @since			4.0
		 * @ignore
		 */
		public function __construct(ipbwi $ipbwi){
			$this->ipbwi	= $ipbwi; // loads common classes
		}
		/**
		 * @desc			Process curl query
		 * @param	string	$endpoint endpoint directories
		 * @param	array	$post_parameters assosiative array of key => value
		 * @param	bool	$delete command to delete data if any found
		 * @return	array	curl result returning transfer
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function process(string $endpoint, array $post_parameters=NULL, bool $delete=NULL, array $get_parameters=NULL){
			if($get_parameters){
				$query = '?'.http_build_query($get_parameters);
			}else{
				$query = '';
			}
			
			$ch = curl_init(ipbwi_IPS_CONNECT_BASE_URL.'api'.$endpoint.$query);
			// get response
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// auth
			curl_setopt($ch, CURLOPT_USERPWD, ipbwi_IPS_REST_API_KEY);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			// update
			if($post_parameters){
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post_parameters);
			}
			// delete
			if($delete === true){
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
			}
			
			// run query
			return json_decode(curl_exec($ch),true);
		}
		/**
		 * @desc			Get basic information about the IPBWI application.
		 * @return	array	IPBWI app information
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function hello(): array{
			$result = $this->process('/ipbwi/hello');
			return $result;
		}
		public function groups(int $id=NULL, array $post_parameters=NULL, bool $delete=NULL){
			if($post_parameters){
				$post_parameters['data']		= json_encode($post_parameters['data']);
			}
			if($id){
				$result = $this->process('/ipbwi/groups/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/ipbwi/groups', $post_parameters);
			}
			return $result;
		}
		public function forums(int $id=NULL, array $post_parameters=NULL, bool $delete=NULL){
			if($post_parameters){
				$post_parameters['data']		= json_encode($post_parameters['data']);
			}
			if($id){
				$result = $this->process('/ipbwi/forums/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/ipbwi/forums', $post_parameters);
			}
			return $result;
		}
		public function reports(int $id=NULL, array $post_parameters=NULL, bool $delete=NULL, array $get_parameters=NULL){
			if($id){
				$result = $this->process('/ipbwi/reports/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/ipbwi/reports', $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		public function members(string $field, string $value): array{
			$result = $this->process('/ipbwi/members/'.$value.'/'.$field);
			return $result;
		}
		public function pages_databases(): array{
			$result = $this->process('/ipbwi/pages');
			return $result;
		}
		public function pages_records(int $database_id, int $id=NULL, array $post_parameters=NULL, bool $delete=NULL, array $get_parameters=NULL){
			if($id){
				$result = $this->process('/cms/records/'.$database_id.'/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/cms/records/'.$database_id, $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
	}
?>