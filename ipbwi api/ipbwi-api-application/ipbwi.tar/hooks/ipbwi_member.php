//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class ipbwi_hook_ipbwi_member extends _HOOK_CLASS_
{

	/**
	 * Set Photo
	 *
	 * @param	string	$photo	Photo location
	 * @return	void
	 */
	public function set_pp_main_photo( $photo )
	{
		try
		{
			$return						=  call_user_func_array( 'parent::set_pp_main_photo', func_get_args() );
	      
	        if(isset(\IPS\Settings::i()->ipbwi_hooks_activate_default) && \IPS\Settings::i()->ipbwi_hooks_activate_default == 1 && isset($this) && is_object($this) && method_exists($this, 'apiOutput')){
	            $hooks					= new \IPS\ipbwi\modules\admin\advanced\hooks;
	            $hooks->send(__METHOD__,array('photo_path' => $photo, 'member' => $this->apiOutput()));
	        }
	      
			return $return;
		}
		catch ( \RuntimeException $e )
		{
			if ( method_exists( get_parent_class(), __FUNCTION__ ) )
			{
				return call_user_func_array( 'parent::' . __FUNCTION__, func_get_args() );
			}
			else
			{
				throw $e;
			}
		}
	}

	/**
	 * [ActiveRecord] Save Changed Columns
	 *
	 * @return	void
	 * @note	We have to be careful when upgrading in case we are coming from an older version
	 */
	public function save()
	{
		try
		{
		// trigger this hook only if something has changed
			if(count($this->changed) > 1 ||
			(count($this->changed) == 1 && !isset($this->changed['last_activity']))
			){
				$result						= \IPS\Db::i()->select('mgroup_others','core_members',array('member_id=?',$this->apiOutput()['id']));
				if($result->valid()){
					$groups_orig			= $result->first();
				}else{
					$groups_orig			= false;
				}
	
				$return						= call_user_func_array( 'parent::save', func_get_args() );
	
				if(isset(\IPS\Settings::i()->ipbwi_hooks_activate_default) && \IPS\Settings::i()->ipbwi_hooks_activate_default == 1 && isset($this) && is_object($this) && method_exists($this, 'apiOutput')){
					$hooks					= new \IPS\ipbwi\modules\admin\advanced\hooks;
					$hooks->send(__METHOD__,array('member' => $this->apiOutput(), 'groups_orig' => $groups_orig));
				}
			}else{
				$return						= call_user_func_array( 'parent::save', func_get_args() );
			}
	      
			return $return;
		}
		catch ( \RuntimeException $e )
		{
			if ( method_exists( get_parent_class(), __FUNCTION__ ) )
			{
				return call_user_func_array( 'parent::' . __FUNCTION__, func_get_args() );
			}
			else
			{
				throw $e;
			}
		}
	}

}
