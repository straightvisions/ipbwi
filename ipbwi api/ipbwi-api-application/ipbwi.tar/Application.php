<?php
/**
 * @brief		IPBWI API Application Class
 * @author		<a href='https://ipbwi.com'>Matthias Reuter</a>
 * @copyright	(c) 2016 Matthias Reuter
 * @package		IPS Community Suite
 * @subpackage	IPBWI API
 * @since		22 Mar 2016
 * @version		
 */
 
namespace IPS\ipbwi;

/**
 * IPBWI API Application Class
 */
class _Application extends \IPS\Application
{
	
}