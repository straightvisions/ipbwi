<?php
	/**
	 * @author			Matthias Reuter
	 * @package			core
	 * @copyright		2007-2016 Matthias Reuter
	 * @link			http://ipbwi.com/
	 * @since			4.0
	 * @license			This is no free software. See license.txt or https://ipbwi.com
	 */
	class ipbwi_core extends ipbwi{
		private $ipbwi			= null;
		/**
		 * @desc			Loads other classes of package
		 * @author			Matthias Reuter
		 * @since			4.0
		 * @ignore
		 */
		public function __construct($ipbwi){
			$this->ipbwi	= $ipbwi; // loads common classes
		}
		/**
		 * @desc			Process curl query
		 * @param	string	$endpoint endpoint directories
		 * @param	array	$post_parameters assosiative array of key => value
		 * @param	bool	$delete command to delete data if any found
		 * @param	array	$post_parameters assosiative array of key => value
		 * @return	array	curl result returning transfer
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function process($endpoint, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($get_parameters){
				$query = '?'.http_build_query($get_parameters);
			}else{
				$query = '';
			}
			
			$ch = curl_init(ipbwi_IPS_CONNECT_BASE_URL.'api'.$endpoint.$query);
			// get response
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// auth
			curl_setopt($ch, CURLOPT_USERPWD, ipbwi_IPS_REST_API_KEY);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			// update
			if($post_parameters){
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post_parameters);
			}
			// delete
			if($delete === true){
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
			}
			
			// run query
			return json_decode(curl_exec($ch),true);
		}
		/**
		 * @desc			Get basic information about the community.
		 * @return	array	community information
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function hello(){
			$result = $this->process('/core/hello');
			return $result;
		}
		/**
		 * @desc			Member Interface
		 * @param	int		$id The user ID
		 * @param	array	$post_parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @param	bool	$delete command to delete data if any found with given id
		 * @param	array	$get_parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function members($id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){
				$result = $this->process('/core/members/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/core/members', $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		/**
		 * @desc			Posts Interface
		 * @param	int		$id The post ID
		 * @param	array	$post_parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @param	bool	$delete command to delete data if any found with given id
		 * @param	array	$get_parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function posts($id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){
				$result = $this->process('/forums/posts/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/forums/posts', $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		/**
		 * @desc			Topics Interface
		 * @param	int		$id The post ID
		 * @param	array	$post_parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @param	bool	$delete command to delete data if any found with given id
		 * @param	array	$get_parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function topics($id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){
				$result = $this->process('/forums/topics/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/forums/topics', $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
	}
?>