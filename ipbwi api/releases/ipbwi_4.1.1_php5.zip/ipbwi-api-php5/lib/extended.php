<?php
	/**
	 * @author			Matthias Reuter
	 * @package			extended
	 * @copyright		2007-2016 Matthias Reuter
	 * @link			http://ipbwi.com/
	 * @since			4.0.1
	 * @license			This is no free software. See license.txt or https://ipbwi.com
	 */
	class ipbwi_extended extends ipbwi{
		private $ipbwi			= null;
		/**
		 * @desc			Loads other classes of package
		 * @author			Matthias Reuter
		 * @since			4.0
		 * @ignore
		 */
		public function __construct($ipbwi){
			$this->ipbwi	= $ipbwi; // loads common classes
		}
		/**
		 * @desc			Process curl query
		 * @param	string	$endpoint endpoint directories
		 * @param	array	$post_parameters assosiative array of key => value
		 * @param	bool	$delete command to delete data if any found
		 * @return	array	curl result returning transfer
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function process($endpoint, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($get_parameters){
				$query = '?'.http_build_query($get_parameters);
			}else{
				$query = '';
			}
			
			$curl_url		= ipbwi_IPS_CONNECT_BASE_URL.'api'.$endpoint.$query;
			$ch = curl_init($curl_url);
			// get response
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// auth
			curl_setopt($ch, CURLOPT_USERPWD, ipbwi_IPS_REST_API_KEY);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			// update
			if($post_parameters){
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post_parameters);
			}
			// delete
			if($delete === true){
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
			}
			
			// load custom options
			if(file_exists('curl_custom.php')){
				$module	= 'extended';
				require('curl_custom.php');
			}
			
			// run query
			$result			= curl_exec($ch);
			$decoded		= json_decode($result,true);
			
			if(is_array($decoded)){
				return $decoded;
			}else{
				$status		= curl_getinfo($ch);
				$msg		= '<div class="ipbwi_api_error">There was an error with CURL Request <strong>'.$status['url'].'</strong> with HTTP code <strong>'.$status['http_code'].'</strong></div>';
				if($status['http_code'] == 404){
					$msg		.= '<div class="ipbwi_api_error_more">In most cases, this could be solved by enabling .htaccess powered friendly URLs in IPS Admin Settings. After that, you will need to redownload an .htaccess file again from the REST settings overview.</div>';
				}
				throw new Exception($msg);
				return false;
			}
		}
		/**
		 * @desc			Get basic information about the IPBWI application.
		 * @return	array	IPBWI app information
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function hello(){
			$result = $this->process('/ipbwi/hello');
			return $result;
		}
		public function groups($id=NULL, $post_parameters=NULL, $delete=NULL){
			if($post_parameters){
				$post_parameters['data']		= json_encode($post_parameters['data']);
			}
			if($id){
				$result = $this->process('/ipbwi/groups/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/ipbwi/groups', $post_parameters);
			}
			return $result;
		}
		public function forums($id=NULL, $post_parameters=NULL, $delete=NULL){
			if($post_parameters){
				$post_parameters['data']		= json_encode($post_parameters['data']);
			}
			if($id){
				$result = $this->process('/ipbwi/forums/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/ipbwi/forums', $post_parameters);
			}
			return $result;
		}
		public function reports($id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){
				$result = $this->process('/ipbwi/reports/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/ipbwi/reports', $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		public function members($field, $value){
			$result = $this->process('/ipbwi/members/'.$value.'/'.$field);
			return $result;
		}
		public function updateSecondaryGroups($id, $groups){
			$result = $this->process('/ipbwi/members/'.$id.'/updateSecondaryGroups',array('groups' => json_encode($groups)));
			return $result;
		}
		public function updateCustomProfileFields($id, $fields){
			$result = $this->process('/ipbwi/members/'.$id.'/updateCustomProfileFields',array('fields' => json_encode($fields)));
			return $result;
		}
		public function updatePhotoByUpload($id, $file){
			$file	= new CurlFile($file['tmp_name'], $file['type'], $file['name']);
			$result = $this->process('/ipbwi/members/'.$id.'/updatePhotoByUpload', array('upload_photo' => $file));
			return $result;
		}
		public function updatePhotoByURL($id, $file_url){
			$result = $this->process('/ipbwi/members/'.$id.'/updatePhotoByURL',array('file_url' => $file_url));
			return $result;
		}
		public function deletePhoto($id){
			$result = $this->process('/ipbwi/members/'.$id.'/deletePhoto',NULL,true);
			return $result;
		}
		public function pages_databases(){
			$result = $this->process('/ipbwi/pages');
			return $result;
		}
		public function pages_records($database_id, $id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){
				$result = $this->process('/cms/records/'.$database_id.'/'.$id, $post_parameters, $delete);
			}else{
				$result = $this->process('/cms/records/'.$database_id, $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		public function pages_record_comments($database_id, $record_id=NULL, $id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){ // get/update/delete a specific comment
				$result = $this->process('/cms/comments/'.$database_id.'/'.$id, $post_parameters, $delete, $get_parameters); // no parameters here
			}elseif($record_id){ // get comments from a record
				$result = $this->process('/cms/records/'.$database_id.'/'.$record_id.'/comments', NULL, NULL, $get_parameters);
			}else{ // get/post comments
				$result = $this->process('/cms/comments/'.$database_id, $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		public function pages_record_reviews($database_id, $record_id=NULL, $id=NULL, $post_parameters=NULL, $delete=NULL, $get_parameters=NULL){
			if($id){ // get/update/delete a specific review
				$result = $this->process('/cms/reviews/'.$database_id.'/'.$id, $post_parameters, $delete, $get_parameters); // no parameters here
			}elseif($record_id){ // get reviews from a record
				$result = $this->process('/cms/records/'.$database_id.'/'.$record_id.'/reviews', NULL, NULL, $get_parameters);
			}else{ // get/post reviews
				$result = $this->process('/cms/reviews/'.$database_id, $post_parameters, NULL, $get_parameters);
			}
			return $result;
		}
		public function pages_record_image($database_id, $record_id){
			$result = $this->process('/ipbwi/pages/'.$database_id.'/image/'.$record_id.'');
			return $result;
		}
		public function pages_record_topicid($database_id, $record_id){
			$result = $this->process('/ipbwi/pages/'.$database_id.'/topicid/'.$record_id.'');
			return $result;
		}
		public function sql($post_parameters){
			$result = $this->process('/ipbwi/sql', $post_parameters);
			return $result;
		}
		/**
		 * @desc			Topics Interface
		 * @param	int		$id The topic ID
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function topics($id){
			$result = $this->process('/ipbwi/topics/'.$id);
			return $result;
		}
	}
?>