<?php
	declare(strict_types=1);
	
	require_once('../ipbwi.php');

	// check whether specific email address exists
	try{var_dump($ipbwi->sso->checkemail('contact@ipbwi.com'));}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
?>