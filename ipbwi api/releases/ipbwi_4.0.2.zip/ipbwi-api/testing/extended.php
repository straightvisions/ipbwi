<?php

	require_once('../ipbwi.php');
	echo '<pre>';
	
	// basic ipbwi information
	#try{var_dump($ipbwi->extended->hello());}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	
	// groups
	
	/* // list all groups
	#try{var_dump($ipbwi->extended->groups());}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	*/
	
	/* // get group info
	#try{var_dump($ipbwi->extended->groups(1));}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	*/

	/* // create new group
	try{
		var_dump($ipbwi->extended->groups(false,array('name' => 'new', 'data' => array('g_view_board' => 1, 'g_mem_info' => 0))));
	}catch(Throwable $t){
		echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage();
	}
	*/
	
	/* // update group
	try{
		var_dump($ipbwi->extended->groups(114,array('name' => 'wubwub', 'data' => array('g_view_board' => 1, 'g_mem_info' => 0))));
	}catch(Throwable $t){
		echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage();
	}
	*/

	/* // delete group
	#try{var_dump($ipbwi->extended->groups(116,NULL,1));}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	*/
	
	// forums
	
	/* // list all forums
	try{var_dump($ipbwi->extended->forums());}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	*/
	
	/* // get forum info
	try{var_dump($ipbwi->extended->forums(148));}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	*/
	
	/* // create new forum
	try{
		var_dump($ipbwi->extended->forums(false,array('name' => 'new', 'data' => array('permission_showtopic' => 1, 'forum_allow_rating' => 1))));
	}catch(Throwable $t){
		echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage();
	}
	*/
	
	/* // update forum
	try{
		var_dump($ipbwi->extended->forums(294,array('name' => 'wubwub', 'data' => array('permission_showtopic' => 1, 'forum_allow_rating' => 0))));
	}catch(Throwable $t){
		echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage();
	}
	*/
	
	// delete forum
	try{var_dump($ipbwi->extended->forums(293,NULL,1));}catch(Throwable $t){ echo 'Type Error, line '.$t->getLine().': ' .$t->getMessage(); }
	
	
	echo '</pre>';

?>