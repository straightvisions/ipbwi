<?php
	declare(strict_types=1);
	
	/**
	 * @author			Matthias Reuter
	 * @package			core
	 * @copyright		2007-2016 Matthias Reuter
	 * @link			http://ipbwi.com/
	 * @since			4.0
	 * @license			This is no free software. See license.txt or https://ipbwi.com
	 */
	class ipbwi_core extends ipbwi{
		public $ipbwi			= null;
		/**
		 * @desc			Loads other classes of package
		 * @author			Matthias Reuter
		 * @since			4.0
		 * @ignore
		 */
		public function __construct(ipbwi $ipbwi){
			$this->ipbwi	= $ipbwi; // loads common classes
		}
		/**
		 * @desc			Process curl query
		 * @param	string	$endpoint endpoint directories
		 * @param	array	$post_parameters assosiative array of key => value
		 * @param	bool	$delete command to delete data if any found
		 * @param	array	$post_parameters assosiative array of key => value
		 * @return	array	curl result returning transfer
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function process(string $endpoint, array $post_parameters=NULL, bool $delete=NULL, array $get_parameters=NULL){
			if($get_parameters){ $query = json_encode($get_parameters); }
			else{ $query = false; }
			
			$ch = curl_init(ipbwi_IPS_CONNECT_BASE_URL.'api'.$endpoint.'?'.$query);
			// get response
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			// auth
			curl_setopt($ch, CURLOPT_USERPWD, ipbwi_IPS_REST_API_KEY);
			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			// update
			if($query){
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post_parameters);
			}
			// delete
			if($delete === true){
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
			}
			
			// run query
			return json_decode(curl_exec($ch),true);
		}
		/**
		 * @desc			Get basic information about the community.
		 * @return	array	community information
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function hello(): array{
			$result = $this->process('/core/hello');
			return $result;
		}
		/**
		 * @desc			Member Interface
		 * @param	int		$id The user ID
		 * @param	array	$parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @param	bool	$delete command to delete data if any found with given id
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function members(int $id=NULL, array $parameters=NULL, bool $delete=NULL): array{
			if($id){
				$result = $this->process('/core/members/'.$id, $parameters, $delete);
			}else{
				$result = $this->process('/core/members', $parameters);
			}
			return $result;
		}
		/**
		 * @desc			Posts Interface
		 * @param	int		$id The post ID
		 * @param	array	$parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @param	bool	$delete command to delete data if any found with given id
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function posts(int $id=NULL, array $parameters=NULL, bool $delete=NULL): array{
			if($id){
				$result = $this->process('/forums/posts/'.$id, $parameters, $delete);
			}else{
				$result = $this->process('/forums/posts', $parameters);
			}
			return $result;
		}
		/**
		 * @desc			Topics Interface
		 * @param	int		$id The post ID
		 * @param	array	$parameters assosiative array of key => value, see IP.board ACP -> System -> REST API -> API Reference
		 * @param	bool	$delete command to delete data if any found with given id
		 * @return	array	Response as associative array, otherwise array with fields errorCode and errorMessage, see IP.board ACP -> System -> REST API -> API Reference
		 * @author			Matthias Reuter
		 * @since			4.0
		 */
		public function topics(int $id=NULL, array $parameters=NULL, bool $delete=NULL): array{
			if($id){
				$result = $this->process('/forums/topics/'.$id, $parameters, $delete);
			}else{
				$result = $this->process('/forums/topics', $parameters);
			}
			return $result;
		}
	}
?>